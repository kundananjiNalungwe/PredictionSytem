from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.template import loader
from records.tests import Logistic
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from records.models import patient, patient_record, history
from .forms import PatientForm, PatientRecordForm, UserForm
from django.contrib.auth import authenticate, login
from django.contrib import auth
from django.contrib.auth.models import User
from django.contrib.postgres.search import SearchVector


def index(request):

    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        user = request.user
        template = loader.get_template('homepage/index.html')

        context = {
            'user': user
        }

        return HttpResponse(template.render(context, request))


def patient_records(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        queryset = patient_record.objects.all()

        record_list = queryset  # .order_by("-submit_date", "-updated")
        paginator = Paginator(record_list, 5)

        page_request_var = "page"
        page = request.GET.get(page_request_var)

        try:
            records = paginator.page(page)

        except PageNotAnInteger:

            # If page is not an integer, deliver first page
            records = paginator.page(1)

        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results
            records = paginator.page(paginator.num_pages)

        template = loader.get_template('homepage/patient_records.html')


        context = {
            'patient_records': records,
            "page_request_var": page_request_var,

        }

        return HttpResponse(template.render(context, request))







def search_patient_list(request):
    if not request.user.is_authenticated:
        return render(request, 'homepage/login.html')
    else:
        if request.method == "GET":
            searchTerm = request.GET.get("searchTerm")

            patients_instances = list(patient.objects.filter(patient_id__icontains=searchTerm)) +list(patient.objects.filter(first_name__icontains=searchTerm)) + list(patient.objects.filter(last_name__icontains=searchTerm))
            results = len(patients_instances)

            patient_list = patients_instances  # .order_by("-submit_date", "-updated")
            paginator = Paginator(patient_list, 5)

            page_request_var = "page"
            page = request.GET.get(page_request_var)

            try:
                patients = paginator.page(page)

            except PageNotAnInteger:

                # If page is not an integer, deliver first page
                patients = paginator.page(1)

            except EmptyPage:
                # If page is out of range (e.g. 9999), deliver last page of results
                patients = paginator.page(paginator.num_pages)

            template = loader.get_template('homepage/search_patients.html')

            context = {
                'search_patients': patients,
                "page_request_var": page_request_var,
                'count': results,
                "searchTerm": searchTerm,

            }

            return HttpResponse(template.render(context, request))



def search_patient_records(request):
    if not request.user.is_authenticated:
        return render(request, 'homepage/login.html')
    else:
        if request.method == "GET":
            searchTerm = request.GET.get("searchTerm")

            patients_instances = list(patient.objects.filter(patient_id__icontains=searchTerm)) +list(patient.objects.filter(first_name__icontains=searchTerm)) + list(patient.objects.filter(last_name__icontains=searchTerm))
            print(patients_instances)

            record_objects = []

            for patient_obj in patients_instances:
                record_instances = patient_record.objects.filter(patient=patient_obj)

                for record_obj in record_instances:
                    record_objects.append(record_obj)

            count = len(record_objects)
            record_list = record_objects  # .order_by("-submit_date", "-updated")
            paginator = Paginator(record_list, 5)

            page_request_var = "page"
            page = request.GET.get(page_request_var)

            try:
                records = paginator.page(page)

            except PageNotAnInteger:

                # If page is not an integer, deliver first page
                records = paginator.page(1)

            except EmptyPage:
                # If page is out of range (e.g. 9999), deliver last page of results
                records = paginator.page(paginator.num_pages)

            template = loader.get_template('homepage/search_patient_records.html')

            context = {
                'search_records': records,
                "page_request_var": page_request_var,
                'count': count,
                "searchTerm": searchTerm,

            }

            return HttpResponse(template.render(context, request))



def patient_list(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:

        patients_instances = patient.objects.all()

        patient_list = patients_instances.order_by("last_name")
        paginator = Paginator(patient_list, 5)

        page_request_var = "page"
        page = request.GET.get(page_request_var)

        try:
            patients = paginator.page(page)

        except PageNotAnInteger:

            # If page is not an integer, deliver first page
            patients = paginator.page(1)

        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results
            patients = paginator.page(paginator.num_pages)

        template = loader.get_template('homepage/patient_list.html')

        context = {
            'patients': patients,
            "page_request_var": page_request_var,

        }

        return HttpResponse(template.render(context, request))





def patient_details(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        timestamps = []
        customer = patient.objects.get(pk=id)
        customer_records = patient_record.objects.filter(patient=customer)

        for record in customer_records:
            timestamps += [history.objects.get(patient_record=record)]



        template = loader.get_template('homepage/patient_details.html')

        context = {
            'patient': customer,
            'record_history': timestamps
        }

        return HttpResponse(template.render(context, request))



def create_patient(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        form = PatientForm(request.POST or None)

        if form.is_valid():
            patients_id = form.cleaned_data.get('patient_id')
            first_name = form.cleaned_data.get('first_name')
            last_name = form.cleaned_data.get('last_name')
            gender = form.cleaned_data.get('gender')
            contact = form.cleaned_data.get('contact')
            address = form.cleaned_data.get('address')

            new_patient = patient.objects.create(patient_id=patients_id, first_name=first_name, last_name=last_name, gender=gender,
                                                 contact=contact, address=address)

            return HttpResponseRedirect(new_patient.get_absolute_url())

        else:
            template = loader.get_template('homepage/patient_form.html')

            context = {
                'patient_form': form,
                'title': 'Create new patient',
            }

            return HttpResponse(template.render(context, request))



def edit_patient(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        patient_instance = get_object_or_404(patient, id=id)
        patient_form = PatientForm(request.POST or None, instance=patient_instance)

        template = loader.get_template('homepage/patient_form.html')

        if patient_form.is_valid():
            patient_instance = patient_form.save(commit=False)
            patient_instance.save()


            return HttpResponseRedirect(patient_instance.get_absolute_url())


        else:
            template = loader.get_template('homepage/patient_form.html')

            context = {
                'patient_form': patient_form,
                'title': 'Edit patient',
            }

            return HttpResponse(template.render(context, request))




def delete_patient(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        patient_instance = get_object_or_404(patient, id=id)
        patient_instance.delete()

        return redirect('homepage:patient_list')



def create_record(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        form = PatientRecordForm(request.POST or None)

        if form.is_valid():
            pregnancies = form.cleaned_data.get('pregnancies')
            glucose = form.cleaned_data.get('glucose')
            blood_pressure = form.cleaned_data.get('blood_pressure')
            skin_thickness = form.cleaned_data.get('skin_thickness')
            insulin = form.cleaned_data.get('insulin')
            bmi = form.cleaned_data.get('bmi')
            diabetes_pedigree_function = form.cleaned_data.get('diabetes_pedigree_function')
            age = form.cleaned_data.get('age')

            patient_instance = get_object_or_404(patient, id=id)
            record_instance = patient_record(patient=patient_instance, pregnancies=pregnancies, glucose=glucose,
                                                 blood_pressure=blood_pressure, skin_thickness=skin_thickness,
                                                 insulin=insulin, bmi=bmi, diabetes_pedigree_function=diabetes_pedigree_function,
                                                 age=age)

            # method to determine outcome
            features = [int(pregnancies), int(glucose), int(blood_pressure), int(skin_thickness), int(insulin), int(bmi),
                        int(diabetes_pedigree_function), int(age)]

            logic = Logistic(features)

            result = logic.getY_new()

            if result == 1:
                record_instance.outcome = True
            elif result == 0:
                record_instance.outcome = False

            record_instance.save()
            #
            #

            timestamp = history.objects.create(patient_record=record_instance)

            return HttpResponseRedirect(record_instance.get_absolute_url())

        else:
            template = loader.get_template('homepage/record_form.html')

            context = {
                'record_form': form,
                'title': 'Create new record',
            }

            return HttpResponse(template.render(context, request))



def edit_record(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        record_instance = get_object_or_404(patient_record, id=id)
        record_form = PatientRecordForm(request.POST or None, instance=record_instance)
        history_instance = get_object_or_404(history, patient_record=record_instance)


        if record_form.is_valid():

            record_instance = record_form.save(commit=False)
            pregnancies = record_form.cleaned_data.get('pregnancies')
            glucose = record_form.cleaned_data.get('glucose')
            blood_pressure = record_form.cleaned_data.get('blood_pressure')
            skin_thickness = record_form.cleaned_data.get('skin_thickness')
            insulin = record_form.cleaned_data.get('insulin')
            bmi = record_form.cleaned_data.get('bmi')
            diabetes_pedigree_function = record_form.cleaned_data.get('diabetes_pedigree_function')
            age = record_form.cleaned_data.get('age')

            features = [int(pregnancies), int(glucose), int(blood_pressure), int(skin_thickness), int(insulin),
                        int(bmi),
                        int(diabetes_pedigree_function), int(age)]
            logic = Logistic(features)

            result = logic.getY_new()

            if result == 1:
                record_instance.outcome = True
            elif result == 0:
                record_instance.outcome = False

            record_instance.save()


            history_instance.patient_record = record_instance
            history_instance.save()

            return HttpResponseRedirect(record_instance.get_absolute_url())


        else:
            template = loader.get_template('homepage/record_form.html')

            context = {
                'record_form': record_form,
                'title': 'Edit patient record',
            }

            return HttpResponse(template.render(context, request))


def test_model(request):
    features1 = [8,183,64,0,0,23.3,0.672,32]
    features2 = [2,197,70,45,543,30.5,0.158,53]
    features3 = [5,116,74,0,0,25.6,0.201,30]
    features4 = [8,99,84,0,0,35.4,0.388,50]
    features5 = [2, 153, 72, 35, 0, 33.6, 0.627, 50]
    logic = Logistic(features5)
    name = logic.getName()
    data = logic.getData()
    X = logic.getX()
    Y = logic.getY()
    Predi = logic.getY_new()
    template = loader.get_template('homepage/test_page.html')

    context = {
         'name': name,
         'data': data,
         'X': X,
         'Y': Y,
         'Predi' : Predi

    }

    return HttpResponse(template.render(context, request))



def view_record_details(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        record_instance = get_object_or_404(patient_record, id=id)

        template = loader.get_template('homepage/record_details.html')

        context = {
             'record' : record_instance
        }

        return HttpResponse(template.render(context, request))


def delete_record(request, id):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        record_instance = get_object_or_404(patient_record, id=id)
        patient = record_instance.patient
        record_instance.delete()

        context = {
            "message": "Record deleted successfully",
        }

        return HttpResponseRedirect(patient.get_absolute_url(), context)



def login_user(request):
    if request.user.is_authenticated:

        return render(request, 'homepage/index.html')

    else:
        if request.method == "POST":
            username = request.POST['username']
            password = request.POST['password']

            user = authenticate(username=username, password=password)

            if user is not None:

                if user.is_active:

                    login(request, user)
                    return redirect('homepage:index')

                else:
                    return render(request, 'homepage/login.html', {'error_message': 'Your account has been disabled'})

            else:
                return render(request, 'homepage/login.html', {'error_message': 'Invalid login'})

        return render(request, 'homepage/login.html')


def logout(request):
    auth.logout(request)
    return redirect('homepage:index')




def profile(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        template = loader.get_template('homepage/profile.html')
        user = request.user
        context = {
            'user': user,
        }

        return HttpResponse(template.render(context, request))



def edit_profile(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        user = request.user
        user_instance = get_object_or_404(User, id=user.id)
        user_form = UserForm(request.POST or None, instance=user_instance)


        if user_form.is_valid():
            user_instance = user_form.save(commit=False)
            user_instance.save()

            return redirect('homepage:profile')


        else:
            template = loader.get_template('homepage/profile_form.html')

            context = {
                'user_form': user_form,
                'title': 'Edit Profile',
            }

            return HttpResponse(template.render(context, request))



def change_password(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        if request.method == "POST":
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)  # Important!
                messages.success(request, 'Your password was successfully updated!')
                return redirect('homepage:profile')
            else:
                messages.error(request, 'Incorrect password or password mismatch. Please try again.')
        else:
            form = PasswordChangeForm(request.user)
        return render(request, 'homepage/change_password.html', {
            'form': form
        })



