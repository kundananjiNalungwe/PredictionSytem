from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from django.template import loader
from records.tests import Logistic
from records.models import patient, patient_record, history
from .forms import PatientForm, PatientRecordForm
from django.contrib.auth.views import login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login


def index(request):
    if not request.user.is_authenticated:

        return render(request, 'homepage/login.html')

    else:
        user = request.user
        template = loader.get_template('homepage/index.html')

        context = {
            'user': user,
        }

        return HttpResponse(template.render(context, request))







def patient_records(request):
    queryset = patient_record.objects.all()

    template = loader.get_template('homepage/patient_records.html')

    context = {
        'patient_records': queryset
    }

    return HttpResponse(template.render(context, request))

def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)

        if user is not None:

            if user.is_active:

                login(request, user)
                return redirect('homepage:index')

            else:
                return render(request, 'homepage/login.html', {'error_message': 'Your account has been disabled'})

        else:
            return render(request, 'homepage/login.html', {'error_message': 'Invalid login'})

    return render(request, 'homepage/login.html')





def patient_list(request):
    patients = patient.objects.all()

    template = loader.get_template('homepage/patient_list.html')

    context = {
        'patients': patients
    }

    return HttpResponse(template.render(context, request))






def patient_details(request, id):
    timestamps = []
    customer = patient.objects.get(pk=id)
    customer_records = patient_record.objects.filter(patient=customer)

    for record in customer_records:
        timestamps += [history.objects.get(patient_record=record)]



    template = loader.get_template('homepage/patient_details.html')

    context = {
        'patient': customer,
        'record_history': timestamps
    }

    return HttpResponse(template.render(context, request))



def create_patient(request):
    form = PatientForm(request.POST or None)

    if form.is_valid():
        first_name = form.cleaned_data.get('first_name')
        last_name = form.cleaned_data.get('last_name')
        gender = form.cleaned_data.get('gender')
        contact = form.cleaned_data.get('contact')
        address = form.cleaned_data.get('address')

        new_patient = patient.objects.create(first_name=first_name, last_name=last_name, gender=gender,
                                             contact=contact, address=address)

        return HttpResponseRedirect(new_patient.get_absolute_url())

    else:
        template = loader.get_template('homepage/patient_form.html')

        context = {
            'patient_form': form,
            'title': 'Create new patient',
        }

        return HttpResponse(template.render(context, request))



def edit_patient(request, id):
    patient_instance = get_object_or_404(patient, id=id)
    patient_form = PatientForm(request.POST or None, instance=patient_instance)

    template = loader.get_template('homepage/patient_form.html')

    if patient_form.is_valid():
        patient_instance = patient_form.save(commit=False)
        patient_instance.save()


        return HttpResponseRedirect(patient_instance.get_absolute_url())


    else:
        template = loader.get_template('homepage/patient_form.html')

        context = {
            'patient_form': patient_form,
            'title': 'Edit patient',
        }

        return HttpResponse(template.render(context, request))




def delete_patient(request, id):
    patient_instance = get_object_or_404(patient, id=id)
    patient_instance.delete()

    return redirect('homepage:patient_list')



def create_record(request, id):
    form = PatientRecordForm(request.POST or None)

    if form.is_valid():
        pregnancies = form.cleaned_data.get('pregnancies')
        glucose = form.cleaned_data.get('glucose')
        blood_pressure = form.cleaned_data.get('blood_pressure')
        skin_thickness = form.cleaned_data.get('skin_thickness')
        insulin = form.cleaned_data.get('insulin')
        bmi = form.cleaned_data.get('bmi')
        diabetes_pedigree_function = form.cleaned_data.get('diabetes_pedigree_function')
        age = form.cleaned_data.get('age')

        patient_instance = get_object_or_404(patient, id=id)
        record_instance = patient_record(patient=patient_instance, pregnancies=pregnancies, glucose=glucose,
                                             blood_pressure=blood_pressure, skin_thickness=skin_thickness,
                                             insulin=insulin, bmi=bmi, diabetes_pedigree_function=diabetes_pedigree_function,
                                             age=age)

        # method to determine outcome
        features = [int(pregnancies), int(glucose), int(blood_pressure), int(skin_thickness), int(insulin), int(bmi),
                    int(diabetes_pedigree_function), int(age)]

        logic = Logistic(features)
        #name = logic.getName()
        #data = logic.getData()
        #X = logic.getX()
        #Y = logic.getY()
        result = logic.getY_new()

        if result == 1:
            record_instance.outcome = True
        elif result == 0:
            record_instance.outcome = False

        record_instance.save()
        #
        #

        timestamp = history.objects.create(patient_record=record_instance)

        return HttpResponseRedirect(record_instance.get_absolute_url())

    else:
        template = loader.get_template('homepage/record_form.html')

        context = {
            'record_form': form,
            'title': 'Create new record',
        }

        return HttpResponse(template.render(context, request))



def edit_record(request, id):
    record_instance = get_object_or_404(patient_record, id=id)
    record_form = PatientRecordForm(request.POST or None, instance=record_instance)
    history_instance = get_object_or_404(history, patient_record=record_instance)


    if record_form.is_valid():
        record_instance = record_form.save(commit=False)
      #  logic = Logistic()
       # result = logic.getY_new()

      #  if result == 1:
       #     record_instance.outcome = True
        #elif result == 0:
         #   record_instance.outcome = False

        record_instance.save()
       # record_instance.save()

        history_instance.patient_record = record_instance
        history_instance.save()


        return HttpResponseRedirect(record_instance.patient.get_absolute_url())


    else:
        template = loader.get_template('homepage/record_form.html')

        context = {
            'record_form': record_form,
            'title': 'Edit patient record',
        }

        return HttpResponse(template.render(context, request))


def test_model(request):
    features1 = [8,183,64,0,0,23.3,0.672,32]
    features2 = [2,197,70,45,543,30.5,0.158,53]
    features3 = [5,116,74,0,0,25.6,0.201,30]
    features4 = [8,99,84,0,0,35.4,0.388,50]
    features5 = [2, 153, 72, 35, 0, 33.6, 0.627, 50]
    logic = Logistic(features5)
    name = logic.getName()
    data = logic.getData()
    X = logic.getX()
    Y = logic.getY()
    Predi = logic.getY_new()
    template = loader.get_template('homepage/test_page.html')

    context = {
         'name': name,
         'data': data,
         'X': X,
         'Y': Y,
         'Predi' : Predi

    }

    return HttpResponse(template.render(context, request))



def view_record_details(request, id):
    record_instance = get_object_or_404(patient_record, id=id)

    template = loader.get_template('homepage/record_details.html')

    context = {
         'record' : record_instance
    }

    return HttpResponse(template.render(context, request))


