from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth_views
from django.contrib import admin



app_name = 'homepage'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^patient_records/$', views.patient_records, name='patient_records'),
    url(r'^patient_list/$', views.patient_list, name='patient_list'),
    url(r'^search_patients/$', views.search_patient_list, name='search_patient_list'),
    url(r'^search_patient_records/$', views.search_patient_records, name='search_patient_records'),
    url(r'^patient_details/(?P<id>\d+)/$', views.patient_details, name='patient_details'),
    url(r'^create_patient/$', views.create_patient, name='create_patient'),
    url(r'^update/(?P<id>\d+)/edit_patient/$', views.edit_patient, name='edit_patient'),
    url(r'^(?P<id>\d+)/delete_patient/$', views.delete_patient, name='delete_patient'),
    url(r'^(?P<id>\d+)/create_record/$', views.create_record, name='create_record'),
    url(r'^(?P<id>\d+)/edit_record/$', views.edit_record, name='edit_record'),
    url(r'^(?P<id>\d+)/delete_record/$', views.delete_record, name='delete_record'),
    url(r'^test_model/$', views.test_model, name='test_model'),
    url(r'^(?P<id>\d+)/view_record/$', views.view_record_details, name='view_record'),
    url(r'^login/', views.login_user, name='login'),
    url(r'^logout/', views.logout, name='logout'),
    url(r'^profile/$', views.profile, name='profile'),
    url(r'^edit_profile/$', views.edit_profile, name='edit_profile'),
    url(r'^admin/', admin.site.urls),


]