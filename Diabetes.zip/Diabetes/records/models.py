from django.db import models
from django.urls import reverse

# Create your models here.

GENDER_CHOICES = (
    ('Male','MALE'),
    ('Female', 'FEMALE'),

)
class patient(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    contact = models.CharField(max_length=20)
    address = models.CharField(max_length=100)

    def __str__(self):
        return self.first_name +" "+ self.last_name


    def get_absolute_url(self):
        # return "/posts/detail/%s/" %(self.id)
        return reverse("homepage:patient_details", kwargs={"id": self.id})



class patient_record(models.Model):
    patient = models. ForeignKey(patient, on_delete=models.CASCADE)
    pregnancies = models.IntegerField(default=0)
    glucose = models.IntegerField()
    blood_pressure = models.IntegerField()
    skin_thickness = models.IntegerField()
    insulin = models.IntegerField()
    bmi = models.DecimalField(decimal_places=1, max_digits=4 )
    diabetes_pedigree_function = models.DecimalField(decimal_places=3, max_digits=6)
    age = models.IntegerField()
    outcome = models.BooleanField(default=False)

    def __str__(self):
        return self.patient.first_name +" "+ self.patient.last_name


    def get_absolute_url(self):
        # return "/posts/detail/%s/" %(self.id)
        return reverse("homepage:view_record", kwargs={"id": self.id})






class history(models.Model):
    patient_record = models.ForeignKey(patient_record, on_delete=models.CASCADE)
    submit_date = models.DateTimeField(auto_now=False, auto_now_add=True)
    updated = models.DateTimeField(auto_now=True, auto_now_add=False)

    def __str__(self):
        return '#'+self.patient_record.patient.first_name[0]+""+self.patient_record.patient.last_name[0]+"00"+str(self.pk)