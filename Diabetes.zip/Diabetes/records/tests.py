# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

# Create your tests here.

import pandas as pd
from sklearn.preprocessing import Imputer
from sklearn.linear_model import LogisticRegression
from sklearn import metrics



class Logistic:

    def __init__(self, features):
        self.__name = 'Logistic'
        self.__df = pd.read_csv('Diabetes.csv')

        feature_col_names = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI',
                             'DiabetesPedigreeFunction', 'Age']
        predicted_class_names = ['Outcome']

        self.__X = self.__df[feature_col_names].values
        self.__Y = self.__df[predicted_class_names].values


        fill_0 = Imputer(missing_values = 0, strategy = "mean", axis=0)

        self.__X = fill_0.fit_transform(self.__X)


        self.__lr_model = LogisticRegression(class_weight="balanced", C=0.6, random_state=42)
        self.__lr_model.fit(self.__X, self.__Y.ravel())
        self.__x_new = [features]#[2, 153, 72, 35, 0, 33.6, 0.627, 50]
        self.__y_new = self.__lr_model.predict(self.__x_new)
       


    def getData(self):
        return self.__df

    def getName(self):
        return self.__name

    def getX(self):
        return self.__X

    def getY(self):
        return self.__Y

    def getY_new(self):
        return self.__y_new



