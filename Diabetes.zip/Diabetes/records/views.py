from __future__ import unicode_literals
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from django.template import loader


# Create your views here.


def index(request):
    template = loader.get_template('records/index.html')


    context = {

    }

    return HttpResponse(template.render(context, request))